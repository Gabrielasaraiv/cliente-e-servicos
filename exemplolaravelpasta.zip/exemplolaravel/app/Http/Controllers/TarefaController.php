<?php

namespace App\Http\Controllers;

use App\Models\Tarefa;
use Illuminate\Http\Request;

class TarefaController extends Controller
{
    public function store(Request $request)
    {
        $tarefa = Tarefa::create([
            'titulo' => $request->titulo,
            'descricao' => $request->descricao
        ]);
        return response()->json([
            'status' => true,
            'message' => 'Cadastrado',
            'data' => $tarefa
        ]);
    }

    public function findById($id)
    {
        $tarefa = Tarefa::find($id);
        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'A tarefa não existe'
            ]);
        }
        return response()->json([
            'status' => true,
            'message' => 'Tarefa encontrada',
            'data' => $tarefa
        ]);
    }

    public function findByIdRequest(Request $request)
    {
        $tarefa = Tarefa::find($request->id);
        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'A tarefa não existe'
            ]);
        }
        return response()->json([
            'status' => true,
            'message' => 'Tarefa encontrada',
            'data' => $tarefa
        ]);
    }

    public function getAll()
    {
        $tarefas = Tarefa::all();

        return response()->json([
            'status' => true,
            'data' => $tarefas
        ]);
    }

    public function delete($id)
    {
        $tarefas = Tarefa::find($id);

        if ($tarefas == null) {
            return response()->json([
                'status' => false,
                'message' => 'Tarefa não encontrada'
            ]);
        }

        $tarefas->delete();

        return response()->json([
            'status' => true,
            'message' => 'Tarefa deletada'
        ]);
    }

    public function update(Request $request)
    {
        $tarefa = Tarefa::find($request->id);

        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'Tarefa não encontrada'
            ]);
        }
        
        /* ou
        $tarefa->titulo = $request->titulo;
        $tarefa->descricao = $request->descricao;
        $tarefa->save();

        ou*/
        
        if (isset($request->titulo)) {
            $tarefa->titulo = $request->titulo;
        }

        if (isset($request->descricao)) {
            $tarefa->descricao = $request->descricao;
        }

         if (isset($request->status)) {
            $tarefa->status = $request->status;
        }

        /*com a primeira opção, é uma forma mais rapida e mais facil de relembrar, alem de 
        ja estar no site do laravel, porem só é possivel colocar os campos que estao aqui.
        com essa segunda, é uma forma mais demorada porem funciona da mesma maneira,
        e no insomnia é possivel escrever todos os campos ou só 1 ou 2 por exemplo que
         ira funcionar do mesmo jeito*/

        $tarefa->update();

        return response()->json([
            'status' => true,
            'message' => 'Tarefa atualizada',
            'data' => $tarefa
        ]);
    }
}
