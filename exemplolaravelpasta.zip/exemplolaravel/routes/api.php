<?php

use App\Http\Controllers\TarefaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('tarefa', [TarefaController::class, 'store']);

Route::get('tarefa/{id}', [TarefaController::class, 'findById']);

Route::get('tarefa/{id}/request', [TarefaController::class, 'findByIdRequest']);

Route::get('tarefa', [TarefaController::class, 'getAll']);

Route::delete('tarefa/{id}', [TarefaController::class, 'delete']);

Route::put('tarefa/{id}', [TarefaController::class, 'update']);